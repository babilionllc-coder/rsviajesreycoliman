let nombre = '';
let correo = '';
let asunto = '';
let mensaje = '';
let whatsapp = '';

function sendEmail(){

    nombre = document.getElementById('nombre').value;
    correo = document.getElementById('correo').value.toLowerCase();
    asunto = document.getElementById('asunto').value;
    mensaje = document.getElementById('mensaje').value;
    whatsapp = document.getElementById('tel').value;

    if(validateCampos() && validateEmail() && validateEmail()){
        document.getElementById('enviar').innerHTML = 'Enviando...';
        document.getElementById('enviar').disabled = true;

        let data = {
            nombre,
            correo,
            asunto,
            mensaje,
            whatsapp
        }

        $.ajax({
            type: "POST", 
            url: conf.api+'sendEmail',
            data:JSON.stringify(data),
            traditional:true,
            headers:{
                'Content-Type':'application/json; charset=utf-8',
                'x-api-key':conf.apikey
            },
            success: function(data) {
                document.getElementById('enviar').innerHTML = 'Enviar';
                document.getElementById('enviar').disabled = false;
                document.getElementById('contact-form').reset();

                alert('Correo enviado correctamente')
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                document.getElementById('enviar').innerHTML = 'Enviar';
                document.getElementById('enviar').disabled = false;
                alert("Error al enviar el correo");
             }
        });
    }
}

function validateEmail(){
    let reg = new RegExp('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$');
    if(reg.test(correo)){
        return true;
    }else{
        alert('Ingrese un correo válido')
        return false;
    }
}

function validatePhone(){
    let reg = new RegExp('[0-9]{10}$');
    if(reg.test(whatsapp)){
        return true;
    }else{
        alert('Ingrese un whatsapp válido')
        return false;
    }
}

function validateCampos(){
    if(nombre.length > 3 && asunto.length >= 3 && mensaje.length > 5){
        return true;
    }else{
        alert('Complete los campos')
        return false;
    }
}