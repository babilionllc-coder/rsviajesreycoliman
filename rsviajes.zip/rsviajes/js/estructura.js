let contact = {};
let valorCambio = "0";
let internacionales = [];
let otrosDestinos = [];
let mostrarNacionales = false;

window.addEventListener("load", () => {
  try {
    let dataS = localStorage.getItem("data");
    data = JSON.parse(dataS);
    contact = data.contacto;
    valorCambio = data.datos.find((e) => e.clave == "exchange").valor ?? "0";
    internacionales = data.internacionales;
    otrosDestinos = data.otrosDestinos;
    mostrarNacionales = data.mostrarNacionales;
    loadMenu();
    loadValorCambio();
    loadFooter();
    loadWhatsapp();
  } catch (error) {}
  getInfo();
});

async function getInfo() {
  await $.ajax({
    type: "GET",
    url: conf.api + "getInfo",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": conf.apikey,
    },
    success: function (data) {
      localStorage.setItem("data", JSON.stringify(data));
      contact = data.contacto;
      valorCambio = data.datos.find((e) => e.clave == "exchange").valor ?? "0";
      internacionales = data.internacionales;
      otrosDestinos = data.otrosDestinos;
      mostrarNacionales = data.mostrarNacionales;
      loadMenu();
      loadValorCambio();
      loadFooter();
      loadWhatsapp();
    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
      alert("Error al obtener datos");
    },
  });
}

function loadFooter() {
  html = '<a href="/" class="navbar-brand" style="margin-bottom: 40px;">';
  html += '<img src="images/logo.png" height="90" alt="">';
  html += "</a>";
  html +=
    '<p><i class="fa fa-map-marker-alt mr-2"></i>' +
    contact.direccion +
    ", " +
    contact.ciudad +
    ", " +
    contact.estado +
    ", C.P. " +
    contact.cp +
    ".</p>";
  html += '<p><i class="fa fa-phone-alt mr-2"></i>' + contact.telefono + "</p>";
  html += '<p><i class="fa fa-envelope mr-2"></i>' + contact.correo + "</p>";
  html += '<div class="d-flex justify-content-start mt-4">';
  html +=
    '<a class="social" href="https://www.tiktok.com/@rey.coliman" target="_blank"><img src="images/tiktok_icon.svg"></img></a>';
  html +=
    '<a class="social" href="https://www.facebook.com/REYCOLIMANAGENCIA/" target="_blank"><i class="fab fa-facebook-f"></i></a>';
  html +=
    '<a class="social" href="https://www.instagram.com/rsviajesreycoliman/" target="_blank"><i class="fab fa-instagram"></i></a>';
  html +=
    '<a class="social" href="https://api.whatsapp.com/send/?phone=52' +
    contact.whatsapp +
    '" target="_blank"><i class="fab fa-whatsapp"></i></a>';
  html += "</div>";

  document.getElementById("footer").innerHTML = html;
}

function loadWhatsapp() {
  html =
    '<a href="https://api.whatsapp.com/send/?phone=52' +
    contact.whatsapp +
    '" class="float" target="_blank">';
  html += '<i class="fab fa-whatsapp my-float"></i>';
  html += "</a>";

  document.getElementById("whatsapp").innerHTML = html;
}

function loadValorCambio() {
  html =
    '<a class="btn btn-primary d-none d-lg-block"> <i class="far fa-money-bill-alt"></i>  ' +
    valorCambio +
    " MXN</a>";

  document.getElementById("cambio").innerHTML = html;
}

function loadMenu() {
  html =
    '<img src="images/logo.png" height="70" class="d-inline-block align-text-top" alt="RS Viajes Rey Colimán">';

  document.getElementById("logo").innerHTML = html;

  if (internacionales != null && internacionales.length > 0) {
    html =
      '<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Salidas Garantizadas</a>';
    html += '<div class="dropdown-menu rounded-0 m-0">';
    for (let index = 0; index < internacionales.length; index++) {
      const element = internacionales[index];
      html +=
        '<a href="viajes-internacionales.html?destino=' +
        element.ruta +
        '" class="dropdown-item">' +
        element.titulo +
        "</a>";
    }
    html += "</div>";

    document.getElementById("internacionales").innerHTML = html;
  }

  if (mostrarNacionales) {
    html =
      '<a href="viajes-nacionales.html" class="nav-item nav-link">Viajes Nacionales</a>';

    document.getElementById("nacionales").innerHTML = html;
  }

  if (otrosDestinos != null && otrosDestinos.length > 0) {
    html =
      '<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Más Destinos</a>';
    html += '<div class="dropdown-menu rounded-0 m-0">';
    for (let index = 0; index < otrosDestinos.length; index++) {
      const element = otrosDestinos[index];
      html +=
        '<a href="mas-destinos.html?destino=' +
        element.ruta +
        '" class="dropdown-item">' +
        element.titulo +
        "</a>";
    }
    html += "</div>";

    document.getElementById("mas-destinos").innerHTML = html;
  }
}
