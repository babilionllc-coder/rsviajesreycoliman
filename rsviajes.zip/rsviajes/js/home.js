
let bestSellers = []
let recents = []
let carrousel = []
let revista ='';
let portada = '';


window.addEventListener('load', ()=>{
    getHome();
});

async function getHome(){
    await $.ajax({
        type: "GET", 
        url: conf.api+'getHome',
        headers:{
            'Content-Type':'application/json',
            'x-api-key':conf.apikey
        },
        success: function(data) {
            bestSellers = data.masvendidos;
            recents = data.novedades;
            carrousel.push(...data.agenciabanner)
            carrousel.push(...data.banner)
            portada = data.portada;
            revista = data.revista;
            loadBestSellers();
            loadCarrusel();
            loadRecents();
            loadMagazine();
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert("Error al obtener datos");
         }
    });

}

function loadCarrusel(){
    let slides=[], indicators=[], html='', activeClass
   for (let i = 0; i < carrousel.length; i++) {
        const item = carrousel[i];
        
        activeClass = i == 0 ? 'active' : '';
        html = '<div class="carousel-item position-relative '+ activeClass +'" style="min-height: 100vh;">'
        html += '<img class="position-absolute w-100 h-100" src="'+item.imagen+'" style="object-fit: cover;">'
        html += '<div class="carousel-caption d-flex flex-column align-items-center justify-content-center">'
        html +=    '<div class="p-3" style="max-width: 900px;">'
        html +=        '<h3 class="display-3 text-capitalize text-white mb-3">'+item.titulo+'</h3>'
        html +=        '<p class="mx-md-5 px-5">'+item.desc+'</p>'
        if(item.viaje.startsWith('http')){
            html +=        '<a class="btn btn-outline-light py-3 px-4 mt-3 animate__animated animate__fadeInUp" href="'+item.viaje+'">Ver más detalles</a>'
        }else{
            html +=        '<a class="btn btn-outline-light py-3 px-4 mt-3 animate__animated animate__fadeInUp" href="viaje.html?tour='+item.viaje+'">Ver más detalles</a>'
        }
        html +=    '</div>'
        html += '</div>'
        html += '</div>'
        slides.push(html);

        activeClass = i == 0 ? 'class="active"' : '';
        html = '<li data-target="#header-carousel" data-slide-to="'+i+'" '+activeClass+'></li>'
        indicators.push(html);

    }

    document.getElementById('carousel-indicators').innerHTML = indicators.join('');
    document.getElementById('carousel-items').innerHTML = slides.join('');
}

async function loadBestSellers(){
    let slides=[];
    for (let i = 0; i < bestSellers.length; i++) {
        const item = bestSellers[i];

        if(item.imagen != null && item.imagen != ""){
        
            html =   '<div class="service-item position-relative">'
            html +=   '<img class="img-fluid" src="'+item.imagen+'" alt="">'
            html +=    '<div class="service-text text-center">'
            html +=      '<div class="w-100 bg-white text-center p-4">'
            html +=          '<a class="btn btn-primary" href="viaje.html?tour='+item.viaje+'">Ver más detalles</a>'
            html +=      '</div>'
            html +=     '</div>'
            html +=   '</div>'
    
            slides.push(html);
        }

    }

    const carouselDOM = document.querySelector("#best-sellers");
    carouselDOM.innerHTML = slides.join('');

    $(".best-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1500,
        loop: true,
        dots: false,
        nav : false,
        responsive: {
            0:{
                items:1
            },
            576:{
                items:2
            },
            768:{
                items:3
            },
            992:{
                items:4
            },
            1200:{
                items:5
            }
        }
    });
}

function loadRecents(){
    let slides=[];
    for (let i = 0; i < recents.length; i++) {
        const item = recents[i];

        if(item.imagen != null && item.imagen != ""){
        
            html =   '<div class="service-item position-relative">'
            html +=   '<img class="img-fluid" src="'+item.imagen+'" alt="">'
            html +=    '<div class="service-text text-center">'
            html +=      '<div class="w-100 bg-white text-center p-4">'
            html +=          '<a class="btn btn-primary" href="viaje.html?tour='+item.viaje+'">Ver más detalles</a>'
            html +=      '</div>'
            html +=     '</div>'
            html +=   '</div>'
    
            slides.push(html);
        }
    }

    const carouselDOM = document.querySelector("#recents");
    carouselDOM.innerHTML = slides.join('');

      $(".recents-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1500,
        loop: true,
        dots: false,
        nav : false,
        responsive: {
            0:{
                items:1
            },
            576:{
                items:2
            },
            768:{
                items:3
            },
            992:{
                items:4
            },
            1200:{
                items:5
            }
        }
    });

}

function loadMagazine(){

    html =    '<div class="col-lg-6" style="min-height: 500px;">'
    html +=        '<div class="position-relative h-100">'
    html +=            '<img class="position-absolute h-100" src="'+portada+'" style="object-fit: cover;">'
    html +=        '</div>'
    html +=    '</div>'
    html +=    '<div class="col-lg-6 pt-5 pb-lg-5" >'
    html +=        '<div class="hours-text p-4 p-lg-5 my-lg-5">'
    html +=            '<h6 class="d-inline-block text-primary text-uppercase py-1 px-2">Revista digital</h6>'
    html +=            '<h1 class="mb-4">Conoce la revista digital</h1>'
    html +=            '<p>En nuestra revista digital podrás encontrar los mejores viajes actualizados</p>'
    html +=            '<button onclick="downloadPdf()" class="btn btn-primary mt-2" id="download">Descargar</button>'
    html +=            '<a href="revista.html" class="btn btn-primary mt-2" style="margin-left:15px">Quiero verla</a>'
    html +=        '</div>'
    html +=    '</div>'

    document.getElementById('magazine').innerHTML = html;

}

function downloadPdf(){
    document.getElementById('download').innerHTML = 'Descargando...'
    $('#download').prop('disabled', true);

    fetch(revista)
   .then(resp => resp.status === 200 ? resp.blob() : Promise.reject('Algo salió mal'))
   .then(blob => {
     const url = window.URL.createObjectURL(blob);
     const a = document.createElement('a');
     a.style.display = 'none';
     a.href = url;
     a.download = 'revista.pdf';
     document.body.appendChild(a);
     a.click();
     window.URL.revokeObjectURL(url);

     $('#download').prop('disabled', false);
     document.getElementById('download').innerHTML = 'Descargar'
     alert('La revista se ha descargado'); 
   })
   .catch(() => alert('Error'));
}
