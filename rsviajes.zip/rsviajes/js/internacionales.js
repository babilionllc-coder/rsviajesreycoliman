window.addEventListener('load', ()=>{
    loadIframe();
});

function loadIframe(){
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    destino = urlParams.get('destino');
    html = '<iframe src="https://nefertaritravel.com.mx/sg-'+destino+'/?iframe=yes" width="100%" height="100%" frameborder="0" allowfullscreen="allowfullscreen" style="border: none; width: 100%; height: 100%;"></iframe>'
    document.getElementById('iframe').innerHTML = html;
}
