

window.addEventListener('load', ()=>{
    loadIframe();
});


function loadIframe(){
    html = '<iframe src="https://nefertaritravel.com.mx/sn/?iframe=yes" width="100%" height="100%" frameborder="0" allowfullscreen="allowfullscreen" style="border: none; width: 100%; height: 100%;"></iframe>'
    document.getElementById('iframe').innerHTML = html;
}


