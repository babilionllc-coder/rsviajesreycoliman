let viajes = [];

window.addEventListener("load", () => {
  getTrips();
});

function getTrips() {
  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  destino = urlParams.get("destino");
  $.ajax({
    type: "GET",
    url: conf.api + "getTripsBySlug/" + destino,
    headers: {
      "Content-Type": "application/json",
      "x-api-key": conf.apikey,
    },
    success: function (data) {
      viajes = data.viajes;
      loadViajes();
    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
      alert("Error al obtener el viaje");
    },
  });
}

function loadViajes() {
  let viajesHtml = [];

  if (viajes.length > 0) {
    viajes.forEach((element) => {
      html = '<div class="col-lg-4 col-md-6 col-sm-12">';
      html += '<div class="card">';
      html +=
        '<img class="card-img-top" src="' + element.imagen + '" alt="Imagen">';
      html += '<div class="card-body">';
      html += '<h5 class="card-title">' + element.nombre + "</h5>";
      html += '<div class="card-text">';
      html += '<div class="row">';
      html += '<div class="col-6">';
      html +=
        '<p> <i class="fas fa-sun text-primary"></i> <b>' +
        element.dias +
        " Días</b> </p>";
      html +=
        '<p> <i class="fas fa-moon text-primary"></i> <b>' +
        element.noches +
        " Noche</b></p>";
      html += "</div>";
      html += '<div class="col-6">';
      html += "<b>Desde: </b>";
      html += "<br>";
      html +=
        '<b class="text-primary" style="font-size: 1.5rem; ">$' +
        element.desde +
        " " +
        element.moneda +
        "MXN</b>";
      html += "<br>";
      html +=
        '<span class="text-primary" style="font-size: .8rem; ">+ $' +
        element.impuestos +
        " " +
        element.moneda +
        "</span>";
      html += "</div>";
      html += "</div>";
      html += "</div>";
      html +=
        '<a href="tour.html?tour=' +
        element.enlace +
        '" class="btn btn-primary">MAS DETALLES</a>';
      html += "</div>";
      html += "</div>";
      html += "</div>";

      viajesHtml.push(html);
    });
    document.getElementById("viajes").innerHTML = viajesHtml.join("");
  } else {
    alert("No se encontraron viajes");
  }
}
