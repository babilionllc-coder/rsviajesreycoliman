let revista = '';

window.addEventListener('load', ()=>{
    getMagazine();
});    

async function getMagazine(){
    await $.ajax({
        type: "GET", 
        url: conf.api+'getMagazine',
        headers:{
            'Content-Type':'application/json',
            'x-api-key':conf.apikey
        },
        success: function(data) {
            revista = data.revista;
            loadMagazine();
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert("Error al obtener datos");
         }
    });

}


function loadMagazine(){

    html = '<iframe width="100%" height="700px" allow="fullscreen" frameborder="0" src="https://revista.salonnefertaritravel.com/index.html?pdf='+revista+'"></iframe>'

    document.getElementById('iframe').innerHTML = html;
}

