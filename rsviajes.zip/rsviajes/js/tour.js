let viaje ={};

window.addEventListener('load', ()=>{
    getTrip();
});



function getTrip(){
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    tour = urlParams.get('tour');
    $.ajax({
        type: "GET", 
        url: conf.api+'getTripBySlug/'+tour,
        headers:{
            'Content-Type':'application/json',
            'x-api-key':conf.apikey
        },
        success: function(data) {
            viaje = data.viaje;
            loadViaje();
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert("Error al obtener el viaje");
         }
    });

}



function loadViaje(){
    let fechas=[];

    viaje.fechas.forEach(element => {
       let fecha = element.fecha.split("-");
       let nuevaFecha = `${fecha[2]}/${fecha[1]}/${fecha[0]}`
       fechas.push(nuevaFecha);
    });

    headHtml = '';
    bodyHtml = '';

    if(viaje.hasOwnProperty('enlace')){
        headHtml = '<div class="cabecera-viaje" style="background-image: linear-gradient(rgba(0, 0, 0, var(--opacidad-negro)), rgba(0, 0, 0, var(--opacidad-negro))),  url('+viaje.imagen+');">'
        headHtml +=   '<div class="cabecera-titulo">'
        headHtml +=        '<h2 class="cabecera-texto">'+viaje.nombre+'</h2>'
        headHtml +=    '</div>'
        headHtml += '</div>'



        bodyHtml = '<div class="row">'
        bodyHtml += '<div class="col-lg-8 col-sm-12 contenido-viaje">'
        bodyHtml +=    '<p><b>Visitarás: </b> '+viaje.ciudades+'</p>'
        bodyHtml +=    '<p><span> <i class="fas fa-sun text-primary"></i> <b>'+viaje.dias +' Días</b>  </span> &nbsp; <span> <i class="fas fa-moon text-primary"></i> <b> '+ viaje.noches +' Noches</b></span></p>'
        bodyHtml +=    '<div class="row">'
        bodyHtml +=        '<div class="col-4"><b> DESDE </b><p>$'+viaje.desde+' '+ viaje.moneda+'</p></div>'
        bodyHtml +=       viaje.precio_doble > 0 ?'<div class="col-4"><b> DOBLE </b><p>$'+viaje.precio_doble+' '+ viaje.moneda+'</p></div>' : '<div class="col-4"><b> DOBLE </b><p>CONSULTAR</p></div>'
        bodyHtml +=        viaje.precio_triple > 0 ? '<div class="col-4"><b> TRIPLE </b><p>$'+viaje.precio_triple+' '+ viaje.moneda+'</p></div>': '<div class="col-4"><b> TRIPLE </b><p>CONSULTAR</p></div>'
        bodyHtml +=        viaje.precio_sencilla > 0 ? '<div class="col-4"><b> SENCILLA </b><p>$'+viaje.precio_sencilla+' '+ viaje.moneda+'</p></div>' : '<div class="col-4"><b> SENCILLA </b><p>CONSULTAR</p></div>'
        bodyHtml +=        viaje.precio_junior > 0 ? '<div class="col-4"><b> JUNIOR </b><p>$'+viaje.precio_junior+' '+ viaje.moneda+'</p></div>' : '<div class="col-4"><b> JUNIOR </b><p>CONSULTAR</p></div>'
        bodyHtml +=        viaje.impuestos > 0 ? '<div class="col-4"><b> IMPUESTOS </b><p>$'+viaje.impuestos+' '+ viaje.moneda+'</p></div>' : '<div class="col-4"><b> IMPUESTOS </b><p>YA INCLUIDOS</p></div>'
        bodyHtml +=   '</div>'
        bodyHtml +=    '<div>'
        bodyHtml +=        '<b>Salidas</b>'
        bodyHtml +=        '<br>'
            fechas.forEach(element => {
                bodyHtml += '<p>'+element+'</p>'
            });
        bodyHtml +=    '</div>'
        bodyHtml +=    '<p style="white-space: pre-wrap;"><b> Descripción: </b> <br>  '+viaje.descripcion+'</p>'
        bodyHtml += '</div>'
        bodyHtml += '<div class="col-lg-4 col-sm-12"><img src="'+viaje.imagen+'" width="100%" alt=""></div>'
        bodyHtml += '</div>'


        document.getElementById('viaje-head').innerHTML = headHtml;
        document.getElementById('viaje-body').innerHTML = bodyHtml;




    }else{
        alert("No se enconctró el viaje");


    }

}