
window.addEventListener('load', ()=>{
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    id = urlParams.get('tour');
    html = '<iframe src="https://nefertaritravel.com.mx/tour/'+id+'/?iframe=yes" width="100%" height="100%" frameborder="0" allowfullscreen="allowfullscreen" style="border: none; width: 100%; height: 100%;"></iframe>'

    document.getElementById('iframe').innerHTML = html;}
);



